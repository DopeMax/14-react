import {
  FormattedMessage,
} from 'umi/locale';

export default () => {
  return <div><FormattedMessage id="helloworld" /></div>;
}
