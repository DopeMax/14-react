export default {
  lang: '中文',
  helloworld: '你好',
}
