export default {
  lang: 'English',
  helloworld: 'hello world',
}
