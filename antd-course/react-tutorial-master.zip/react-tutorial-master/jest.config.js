module.exports = {
  testURL: 'http://localhost:7001',
};
